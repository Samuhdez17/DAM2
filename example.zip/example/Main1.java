package org.example;

import jakarta.xml.bind.*;

import java.io.File;

public class Main1 {
    public static  void main(String[] args) throws JAXBException {
        Libreria1 lib =  new Libreria1("Las Hojas","Getafe");
        lib.getLibros().add(new Libro1("Cervantes","Quijote", "El barco de Vapor" , "1234"));
        lib.getLibros().add(new Libro1("Fernando de Rojas", "La Celestina", "Anaya", "1456"));

        //Creamos el contexto JAXB

        //Ponemos una nueva instancia de Libreria porque es la principal, quien va a construir todo

        JAXBContext contexto = JAXBContext.newInstance(Libreria1.class);

        //Marshalling --> Objetos Java a XML
        Marshaller marshaller = contexto.createMarshaller();
        //Propiedad, formato de salida
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        System.out.println("Generando XML...");

        //Los objetos los mete en el XML
        marshaller.marshal(lib, new File("Libreria1.xml"));
        //Aqui los pinta en el XML
        marshaller.marshal(lib,System.out);

        System.out.println("XML generado");

        System.out.println("Leemos el XML....");
        //Unmarshalling XML a Objetos XML
        Unmarshaller unmarshaller = contexto.createUnmarshaller();
        Libreria1 libreriaGetafe = (Libreria1) unmarshaller.unmarshal(new File("Libreria1.xml"));
        System.out.println(libreriaGetafe);


    }
}
