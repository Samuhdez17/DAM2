package org.example;


import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "Libreria1")
public class Libreria1 {

    private String nombre;
    private String lugar;
    private List<Libro1> libro1s = new ArrayList<>();

    public Libreria1() {
    }

    public Libreria1(String nombre, String lugar) {
        this.nombre = nombre;
        this.lugar = lugar;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    @XmlElementWrapper(name = "libro1s")
    @XmlElement(name = "Libro")

    public List<Libro1> getLibros() {
        return libro1s;
    }

    public void setLibros(List<Libro1> libro1s) {
        this.libro1s = libro1s;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Librería: ").append(this.nombre).append(" (").append(this.lugar).append(")\n");
        sb.append("Libros:\n");
        for (Libro1 libro1 : this.libro1s) {
            sb.append(" - ").append(libro1).append("\n");
        }
        return sb.toString();
    }
}

