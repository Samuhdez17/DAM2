package com.example.appincidencias.data.model

data class Incidencia(
    val id: Int,
    val titulo: String,
    val descripcion: String,
    val estado: String,
    val fecha: String,
)
